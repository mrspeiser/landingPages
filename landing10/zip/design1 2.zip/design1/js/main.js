(function(){

$('#login').on('click', function(){
	$('#login-form').toggle().css({'height': '400', 'opacity': '1', 'transition':'all 300ms ease-in-out'});
});

$('#login').on('click', function(){
	$('.login-form').toggleClass('form-show');
});

})();
